<?php
class product {

    public $product_id;
    public $name;
    public $description;
    public $price;
    public $stock;
    public $image;

    public function setProduct_id($product_id) {
        $this->product_id = $product_id;
    }
    public function getProduct_id() {
        return $this->product_id;
    }
    
    public function setName($name) {
        $this->name = $name;
    }
    public function getName() {
        return $this->name;
    }

    public function setDescription($description) {
        $this->description = $description;
    }
    public function getDescription() {
        return $this->description;
    }

    public function setPrice($price) {
        $this->price = $price;
    }
    public function getPrice() {
        return $this->price;
    }

    public function setStock($stock) {
        $this->stock = $stock;
    }
    public function getStock() {
        return $this->stock;
    }
    
    public function setImage($image) {
        $this->image = $image;
    }
    public function getImage() {
        return $this->image;
    }

    public function displayProduct() {
    echo"<br>---------------------";
    echo"<br>--- PRODUCT ---";
    echo"<br>---------------------";
    echo"<br>ID: " . $this->getProduct_id();
    echo"<br>Name: " . $this->getName();
    echo"<br>Description: " . $this->getDescription();
    echo"<br>Price: " . $this->getPrice();
    echo"<br>Stock: " . $this->getStock();
    echo "<br><img src='" . $this->getImage() . "' width='150' alt='" . $this->getName() . "'>";
    }
}
?>